"""API routes for the trading service."""

import asyncio
import logging
import os
from typing import Any, Dict, List

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from .accounts import AccountStatus, account_service
from .balances import balance_service
from .copy_dispatcher import copy_dispatcher
from .models import CopyStatusResponse, LeaderConfig, StatusResponse
from .storage import load_leader_credentials, save_leader_credentials
from api.follower_accounts import router as follower_accounts_router

# ---------------------------------------------------------------------------
# Authentication helpers
# ---------------------------------------------------------------------------

API_TOKEN = os.getenv("API_TOKEN", "")


async def verify_token(authorization: str = Header("")) -> None:
    """Validate ``Authorization`` header against ``API_TOKEN`` env var."""
    if not API_TOKEN:
        return
    expected = f"Bearer {API_TOKEN}"
    if authorization != expected and authorization != API_TOKEN:
        raise HTTPException(status_code=401, detail="Unauthorized")

# ---------------------------------------------------------------------------
# Background tasks
# ---------------------------------------------------------------------------

_leader_task: asyncio.Task | None = None


async def _run_leader_watcher(cfg: LeaderConfig) -> None:
    from . import leader_watcher
    logging.info("[LEADER] _run_leader_watcher starting...")

    try:
        logging.info("[LEADER] launching watch_leader_orders stream...")
        async for event in leader_watcher.watch_leader_orders(
            cfg.api_key,
            cfg.api_secret,
            testnet=cfg.env == "test",
        ):
            try:
                logging.info(f"[LEADER] received event: {event.get('type')}")
                await copy_dispatcher.dispatch(event)
            except Exception:
                logging.exception("dispatch failed")
    except Exception as e:    
        import traceback 
        logging.error(f"❌ leader watcher failed: {e}")
        logging.error(traceback.format_exc())


# Routers
public_router = APIRouter()
protected_router = APIRouter()

# ---------------------------------------------------------------------------
# Public endpoints
# ---------------------------------------------------------------------------

@public_router.get("/status", response_model=StatusResponse)
async def read_status() -> StatusResponse:
    """Simple health check endpoint."""
    return StatusResponse(status="ok")

# ---------------------------------------------------------------------------
# Protected endpoints
# ---------------------------------------------------------------------------

@protected_router.get("/balances/{account}")
async def read_balance(account: str) -> Dict[str, float | bool]:
    """Return the most recently cached balance for ``account``."""
    return await balance_service.get_balance(account)


@protected_router.put("/leader")
async def configure_leader(config: LeaderConfig) -> Dict[str, bool]:
    """Persist leader credentials and start watching orders."""
    save_leader_credentials(config.dict())

    global _leader_task
    if _leader_task:
        _leader_task.cancel()
        try:
            await _leader_task
        except Exception:
            pass

    _leader_task = asyncio.create_task(_run_leader_watcher(config))
    print("🔥🔥🔥 configure_leader() 被调用了并成功创建了 watcher task")
    logging.info("[LEADER] watcher restarted in background")
    return {"listening": True}


@protected_router.get("/copy/status", response_model=CopyStatusResponse)
async def get_copy_status() -> CopyStatusResponse:
    """Return dispatcher running state and stored leader API key."""
    creds = load_leader_credentials()
    leader = creds.get("api_key") if isinstance(creds, dict) else None
    return CopyStatusResponse(running=copy_dispatcher.is_running(), leader=leader)


@protected_router.post("/copy/start")
async def start_copy() -> Dict[str, bool]:
    """Enable order copying."""
    copy_dispatcher.start()
    return {"running": True}


@protected_router.post("/copy/stop")
async def stop_copy() -> Dict[str, bool]:
    """Disable order copying."""
    copy_dispatcher.stop()
    return {"running": False}


@protected_router.get("/copy/results")
async def get_copy_results() -> Dict[str, Dict[str, Any]]:
    """Return the results of the most recent copy trade dispatch."""
    return copy_dispatcher.get_last_results()

# ---------------------------------------------------------------------------
# Account management
# ---------------------------------------------------------------------------

class AccountStatusPayload(BaseModel):
    """Payload for updating an account's status."""
    status: AccountStatus

@protected_router.get("/accounts")
async def list_accounts() -> List[Dict[str, Any]]:
    """Return all configured accounts."""
    return [acc.to_dict() for acc in account_service.list_accounts()]


@protected_router.put("/accounts/{name}/status")
async def update_account_status(
    name: str, payload: AccountStatusPayload
) -> Dict[str, str]:
    """Update the status of an account."""
    account_service_
